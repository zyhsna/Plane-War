package main;
//���˵÷�
public interface Enemy {
	public abstract int getScore();
}
