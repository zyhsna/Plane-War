package main;
//���˵÷�
public interface Enemy {
	public int getScore();

}
